import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Pr11Component } from './pr11.component';

describe('Pr11Component', () => {
  let component: Pr11Component;
  let fixture: ComponentFixture<Pr11Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Pr11Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Pr11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
