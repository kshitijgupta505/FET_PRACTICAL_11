import { Component } from '@angular/core';

@Component({
  selector: 'app-pr11',
  templateUrl: './pr11.component.html',
  styleUrls: ['./pr11.component.scss']
})
export class Pr11Component {
  result:number =0;
  add()
  {
  var x:number =Number( prompt("Enter a Value", "1"));
  var y:number =Number( prompt("Enter a Value", "2"));
  this.result= x+y;
  }
  div()
  {
  var x:number =Number( prompt("Enter a Value", "1"));
  var y:number =Number( prompt("Enter a Value", "2"));
  this.result = x/y;
  }
  mul()
  {
  var x:number =Number( prompt("Enter a Value", "1"));
  var y:number =Number( prompt("Enter a Value", "2"));
  this.result = x*y;
  }
  sub()
  {
  var x:number =Number( prompt("Enter a Value", "1"));
  var y:number =Number( prompt("Enter a Value", "2"));
  this.result= x-y;
  }
  
}
